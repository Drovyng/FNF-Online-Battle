.. Places parent toc into the sidebar

:parenttoc: True

.. include:: includes/big_toc_css.rst

===========
Dispatching
===========

.. toctree::
    :maxdepth: 2

    modules/array_api
